document.addEventListener("DOMContentLoaded", function () {
  // menambahkan action click kepada tombol yang jika ditekan maka akan memanggil fungsi loadTasks
});

function loadTasks() {
  //Membaca file JSON yang telah dibuat
  //Jika file JSON terbaca dan ada datanya tasknya, maka lanjutkan ke fungsi DisplayTasks
}

function displayTasks(tasks) {
  /*
        Dari data JSON yang diterima dari parameter (berbentuk array),
        Silahkan lakukan looping setiap tasks nya untuk ditampilkan pada table
    */

  tasks.forEach(function (task) {
    //Di sini ada menunjukkan data. Data dimasukin ke dalam table (row dan col.)
  });
}
